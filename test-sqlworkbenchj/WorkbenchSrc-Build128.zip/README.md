# SQL Workbench/J

This is the public Git repository for SQL Workbench/J

Homepage and downloads are here: http://www.sql-workbench.eu

License information can be found at: https://www.sql-workbench.eu/manual/license.html

